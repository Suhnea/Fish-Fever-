import pygame
from sys import exit
import time
import random

pygame.init()

# звук
pygame.mixer.init()

pygame.mixer.music.load('Music.wav') 
collision_sound = pygame.mixer.Sound('High_Score.wav')
menu_sound = pygame.mixer.Sound('Menu.wav')

width = 800
height = 400
screen = pygame.display.set_mode((width, height))

fps = 60
clock = pygame.time.Clock()

start_time = 0
final_score = 0

back_main_screen = pygame.image.load('menu.png').convert_alpha()
back = pygame.image.load('backgr.png').convert_alpha()
hero = pygame.image.load('plenon.png').convert_alpha()
bas = pygame.image.load('1.png').convert_alpha()
fra = pygame.image.load('6.png').convert_alpha()
gold = pygame.image.load('10.png').convert_alpha()

pygame.display.set_caption("Fish Fever!")

game = False

text_font = pygame.font.Font('prstartk.ttf', 15)
text_font_collide = pygame.font.Font('prstartk.ttf', 50)
text_font_new_game = pygame.font.Font('prstartk.ttf', 20)

text_surface = text_font.render('Fish Fever!', False, 'White')
text_name_rect = text_surface.get_rect(center=(400, 15))
text_collide = text_font_collide.render('Fish Attack!', False, 'Red')
text_collide_rect = text_collide.get_rect(center=(400, 200))
text_newgame_str1 = text_font_new_game.render('press SPACE to start', False, 'White')
text_newgame_rect1 = text_newgame_str1.get_rect(center=(400, 375))

text_font_score = pygame.font.Font('prstartk.ttf', 15)
text_ts_font = pygame.font.Font('prstartk.ttf', 20)

# Начальная скорость
initial_speed = 3
speed_increase_interval = 10000  # каждые 10 секунд

def display_score():
    current_time = pygame.time.get_ticks() - start_time
    score_surface = text_font_score.render(f'{current_time}', False, "White")
    score_rect = score_surface.get_rect(bottomright=(795, 395))
    screen.blit(score_surface, score_rect)

def reset_game():
    global hero_rect, gold_rect, bas_rect, fra_rect, gold_flag, fra_flag, game, current_speed, last_speed_increase
    global bas_speed, gold_speed, fra_speed

    hero_x_pos = 70
    hero_y_pos = 180
    bas_x_pos = 750
    bas_y_pos = 90
    fra_x_pos = 750
    fra_y_pos = 205
    gold_x_pos = 750
    gold_y_pos = 320

    hero_rect = hero.get_rect(center=(hero_x_pos, hero_y_pos))
    gold_rect = gold.get_rect(center=(gold_x_pos, gold_y_pos))
    bas_rect = bas.get_rect(center=(bas_x_pos, bas_y_pos))
    fra_rect = fra.get_rect(center=(fra_x_pos, fra_y_pos))

    gold_flag = False
    fra_flag = False

    current_speed = initial_speed
    last_speed_increase = pygame.time.get_ticks()

    bas_speed = initial_speed
    gold_speed = initial_speed + 1
    fra_speed = initial_speed

reset_game()

# Музыка бесконечно
pygame.mixer.music.play(-1)

# моё дополнение. стандарт скорость
bas_speed = initial_speed
gold_speed = initial_speed + 1
fra_speed = initial_speed

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        
        if not game and event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            reset_game()
            game = True
            start_time = pygame.time.get_ticks()
            menu_sound.play()
            pygame.mixer.music.unpause()  # + фон

    if game:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            hero_rect.top -= 5
            if hero_rect.top <= 0:
                hero_rect.top = 0
        if keys[pygame.K_DOWN]:
            hero_rect.top += 5
            if hero_rect.bottom >= 400:
                hero_rect.bottom = 400
        
        screen.blit(back, (0, 0))
        screen.blit(hero, hero_rect)
        screen.blit(bas, bas_rect)
        screen.blit(fra, fra_rect)
        screen.blit(gold, gold_rect)
        back.blit(text_surface, text_name_rect)

        # + скорость каждые 10 секунд
        current_time = pygame.time.get_ticks()
        if current_time - last_speed_increase > speed_increase_interval:
            current_speed += 1
            last_speed_increase = current_time

        # рыбы с постоянной скоростью
        bas_rect.left -= bas_speed
        if bas_rect.left <= 400:
            gold_flag = True
        if gold_flag:
            gold_rect.left -= gold_speed
        if gold_rect.left <= 400:
            fra_flag = True
        if fra_flag:
            fra_rect.left -= fra_speed
    
        # новый круг с рандомом
        if bas_rect.right <= 0:
            bas_rect.left = 1150
            bas_rect.top = random.randint(50, 150)
            bas_speed = current_speed + random.randint(-1, 1)
        if gold_rect.right <= 0:
            gold_rect.left = 1050
            gold_rect.top = random.randint(150, 250)
            gold_speed = current_speed + 1 + random.randint(-1, 1)
        if fra_rect.right <= 0:
            fra_rect.left = 850
            fra_rect.top = random.randint(250, 350)
            fra_speed = current_speed + random.randint(-1, 1)

        if hero_rect.colliderect(bas_rect) or hero_rect.colliderect(gold_rect) or hero_rect.colliderect(fra_rect):
            screen.blit(text_collide, text_collide_rect)
        
            final_score = (pygame.time.get_ticks() - start_time) // 1000
            text_ts_text = text_ts_font.render(f'Total time: {final_score} sec', False, 'Red')
            text_ts_rect = text_ts_text.get_rect(center=(400, 250))
            screen.blit(text_ts_text, text_ts_rect)
    
            pygame.display.flip()
            pygame.mixer.music.pause()  # - фон
            collision_sound.play()  # столкновение
            time.sleep(3)
            game = False
            pygame.mixer.music.play(-1)  # + фон

        display_score()

    else:
         screen.blit(back_main_screen, (0,0))
         screen.blit(text_newgame_str1, text_newgame_rect1)
         pygame.display.update()

    pygame.display.update()
    clock.tick(fps)